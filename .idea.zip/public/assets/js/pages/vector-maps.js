$(function(){
	$('#vmap-1').vectorMap({map: 'world_mill_en',backgroundColor: 'transparent',
            regionStyle: {
              initial: {
                fill: '#8d8d8d'
              }
            }});
	$('#vmap-3').vectorMap({map: 'europe_mill_en',backgroundColor: 'transparent',
            regionStyle: {
              initial: {
                fill: '#8d8d8d'
              }
            }});
	$('#vmap-4').vectorMap({map: 'us_aea_en',backgroundColor: 'transparent',
            regionStyle: {
              initial: {
                fill: '#8d8d8d'
              }
            }});
	$('#vmap-5').vectorMap({map: 'uk_mill_en',backgroundColor: 'transparent',
            regionStyle: {
              initial: {
                fill: '#8d8d8d'
              }
            }});
	$('#vmap-6').vectorMap({map: 'us-il-chicago_mill_en',backgroundColor: 'transparent',
            regionStyle: {
              initial: {
                fill: '#8d8d8d'
              }
            }});
});