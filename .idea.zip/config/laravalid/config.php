<?php

return [
	'useLaravelMessages'	=>	true,
	'plugin'	=>	'JqueryValidation',
	'route'	=>	'laravalid'
];